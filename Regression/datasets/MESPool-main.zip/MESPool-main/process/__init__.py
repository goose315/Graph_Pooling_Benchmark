# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 15:36:43 2022

@author: Fanding Xu
"""

from .trainer import Trainer

__all__ = ['Trainer']